$(document).ready(function() {
    $(".action-add").click(function() {
		$("#my-list").append("<tr><td class='test'>" + $(".item-input").val() + "</td><td> <button type='button' class='action-delete'>Delete</button><button type='button' type='action-done' class='action-done'>Done</button> <button type='button' type='action-edit' class='action-edit'>Edit</button></td></tr>");
		//Deleting items from list
		$("#my-list").on("click", ".action-delete", function(){
			$(this).parent().parent().remove();
		});
		$("#my-list").on("click", ".action-done", function(){
			$(this).parent().parent().find( "td:first" ).css( "text-decoration", "line-through");
		});
		$("#my-list").on("click", ".action-edit", function(){
			$(this).parent().parent().edit();
			
		});
	});
});